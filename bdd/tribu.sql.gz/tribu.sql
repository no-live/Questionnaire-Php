-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : jeu. 06 juil. 2023 à 18:10
-- Version du serveur : 8.0.30
-- Version de PHP : 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tribu`
--

-- --------------------------------------------------------

--
-- Structure de la table `link_quest`
--

CREATE TABLE `link_quest` (
  `id_lk_questionnaire` int NOT NULL,
  `id_lk_question` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `link_quest`
--

INSERT INTO `link_quest` (`id_lk_questionnaire`, `id_lk_question`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `id_question` int NOT NULL,
  `contenu_question` text COLLATE utf8mb4_general_ci NOT NULL,
  `multi_rep` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `question`
--

INSERT INTO `question` (`id_question`, `contenu_question`, `multi_rep`) VALUES
(1, 'Comment avez-vous découvert notre site web?', 1);

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire`
--

CREATE TABLE `questionnaire` (
  `id_questionnaire` int NOT NULL,
  `nom_questionnaire` text COLLATE utf8mb4_general_ci NOT NULL,
  `date_questionnaire` date NOT NULL,
  `quest_check` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `questionnaire`
--

INSERT INTO `questionnaire` (`id_questionnaire`, `nom_questionnaire`, `date_questionnaire`, `quest_check`) VALUES
(1, 'Questionnaire1', '2023-07-05', 1);

-- --------------------------------------------------------

--
-- Structure de la table `quest_rep`
--

CREATE TABLE `quest_rep` (
  `id_questrep` int NOT NULL,
  `id_repquest` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `quest_rep`
--

INSERT INTO `quest_rep` (`id_questrep`, `id_repquest`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE `reponse` (
  `id_rep` int NOT NULL,
  `contenu_rep` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `reponse`
--

INSERT INTO `reponse` (`id_rep`, `contenu_rep`) VALUES
(1, 'R&eacute;ponse A'),
(2, 'R&eacute;ponse B');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `date_user` date NOT NULL,
  `nom_questionnaire` text COLLATE utf8mb4_general_ci NOT NULL,
  `tb_choix` text COLLATE utf8mb4_general_ci NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id_user`, `date_user`, `nom_questionnaire`, `tb_choix`, `url`) VALUES
(1, '2023-07-06', '', '[\"1 \\/ 1\",\"1 \\/ 2\"]', ''),
(4, '2023-07-06', '', '[\"1 \\/ 1\"]', ''),
(5, '2023-07-06', '', '[\"1 \\/ 2\"]', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `link_quest`
--
ALTER TABLE `link_quest`
  ADD PRIMARY KEY (`id_lk_questionnaire`,`id_lk_question`),
  ADD KEY `id_lk_question` (`id_lk_question`);

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id_question`);

--
-- Index pour la table `questionnaire`
--
ALTER TABLE `questionnaire`
  ADD PRIMARY KEY (`id_questionnaire`);

--
-- Index pour la table `quest_rep`
--
ALTER TABLE `quest_rep`
  ADD PRIMARY KEY (`id_questrep`,`id_repquest`),
  ADD KEY `id_repquest` (`id_repquest`);

--
-- Index pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`id_rep`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `question`
--
ALTER TABLE `question`
  MODIFY `id_question` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `questionnaire`
--
ALTER TABLE `questionnaire`
  MODIFY `id_questionnaire` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `reponse`
--
ALTER TABLE `reponse`
  MODIFY `id_rep` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `link_quest`
--
ALTER TABLE `link_quest`
  ADD CONSTRAINT `link_quest_ibfk_1` FOREIGN KEY (`id_lk_questionnaire`) REFERENCES `questionnaire` (`id_questionnaire`),
  ADD CONSTRAINT `link_quest_ibfk_2` FOREIGN KEY (`id_lk_question`) REFERENCES `question` (`id_question`);

--
-- Contraintes pour la table `quest_rep`
--
ALTER TABLE `quest_rep`
  ADD CONSTRAINT `quest_rep_ibfk_1` FOREIGN KEY (`id_questrep`) REFERENCES `question` (`id_question`),
  ADD CONSTRAINT `quest_rep_ibfk_2` FOREIGN KEY (`id_repquest`) REFERENCES `reponse` (`id_rep`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
